module.exports = {
  theme: {
    fontFamily: {
      sans: ['halyard-display', 'sans-serif'],
    },
    colors: {
      white: '#fff',
      green: '#2ECF62',
      darkGreen: '#1B2723',
      dark: '#111E1A',
      lightGreen: '#E6F0ED',
    },

    extend: {}
  },
  variants: {},
  plugins: []
}
