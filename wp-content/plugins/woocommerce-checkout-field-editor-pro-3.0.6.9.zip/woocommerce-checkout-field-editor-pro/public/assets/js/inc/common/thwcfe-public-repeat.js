var thwcfe_public_repeat = (function($, window, document) {
	'use strict';

	/*function setup_repeat_section_fields(wrapper){
		wrapper.find('.thwcfe-repeat-section').each(function(){										 
			prepare_extra_cost_from_selected_option($(this), 'select');
		});

		wrapper.find('.thwcfe-repeat-trigger').change(function(){
			
		});
	}
	
	function repeat_section(celm, validations, needSetup){
		
	}
	
	
	
	return {
		
	};*/
}(window.jQuery, window, document));
